# TrabalhoFinal-Twice
<h2> Trabalho final de Banco de dados, PTAC3 e PTAS3</h2>
<h3> feito pela Maylla e Maria luiza </h3>
<h3>Para iniciar o front-end de: <br/>
npm install <br/>
npm install react-responsive-carousel <br/>
npm i lucide-react <br/>
npm run dev
</h3>

<h3>Para iniciar o back-end de: <br/>
npm install <br/>
npm start
</h3>
<h3> Banco de dados se tiver sem internet</h3>
<p> /*postgres://postgres:postgres@localhost/produto*/ </p>


