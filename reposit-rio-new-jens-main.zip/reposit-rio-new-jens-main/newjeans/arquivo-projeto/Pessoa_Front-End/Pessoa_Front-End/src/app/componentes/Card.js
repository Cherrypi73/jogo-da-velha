export default function Card(){
    return(
        <div className="grid grid-cols-3 gap-4 mt-6">
              
            
            </div>
    )
}