const db = require("../db"); // requere o banco de dados de db

class Produto{
  static async select() { // seleciona a função estatica assincrona
    try {
      const connect = await db.connect(); //permite que uma função assíncrona e sem bloqueio seja estruturada de maneira semelhante a uma função síncrona comum
      const sql = "SELECT *FROM produtos"
      return await connect.query(sql);
    } catch (error) {
      console.error('Erro em select:', error);
      throw error;
    }
  }
  static async selectOne(id) { //faz o select individual do id
    try {
      const connect = await db.connect();
      const sql = "SELECT *FROM produtos WHERE codigo=$1";
      return await connect.query(sql,[id]);
    } catch (error) { //query() realiza uma consulta simples, a cada chamada uma consulta é enviada para o banco, ao utilizar esse método o programador é responsável por sanitizar os valores passados
      console.error('Erro em select:', error);
      throw error;
    }
  }

  static async insert(data) { //O método update modifica a entidade especificada do objeto de dados raiz
    try {
      const connect = await db.connect();
      const sql = "INSERT INTO produtos (titulo, data_cadastro, preco, descricao, imagem) VALUES ($1, $2, $3, $4,$5) RETURNING titulo, data_cadastro, preco, descricao, imagem;";
      const values = [data.titulo, data.data_cadastro, data.preco, data.descricao, data.imagem];
      return await connect.query(sql, values);
    } catch (error) {
      console.error('Erro em insert:', error);
      throw error;
    }
  }

  static async update(id, data) {
    try {
      const connect = await db.connect();
      const sql = "";
      const values = [data.titulo, data.data_cadastro, data.preco, data.descricao, data.imagem, id];
      return await connect.query(sql, values);
    } catch (error) {
      console.error('Erro em update:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const connect = await db.connect();
      const sql = "DELETE FROM produtos WHERE codigo=$1";
      return await connect.query(sql, [id]);
    } catch (error) {
      console.error('Erro em delete:', error);
      throw error;
    }
  }
}

module.exports = Produto;
